package ir.sharif.androidworkshop;

import java.io.Serializable;

public class MohammadModel implements Serializable {
    private String s1;
    private String s2;
    private String s3;
    private String s4;
    private String s5;
    private String s6;




}

package ir.sharif.androidworkshop;

public class Animal {
    private String name;
    private String skinColor;
    private int energy;

    public Animal(String name, String skinColor, int energy) {
        this.name = name;
        this.skinColor = skinColor;
        this.energy = energy;
    }

    public String getName() {
        return name;
    }

    public String getSkinColor() {
        return skinColor;
    }

    public int getEnergy() {
        return energy;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSkinColor(String skinColor) {
        this.skinColor = skinColor;
    }

    public void setEnergy(int energy) {
        this.energy = energy;
    }
}

package ir.sharif.androidworkshop;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PermissionActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int CALL_PERMISSION_REQUEST_CODE = 1001;
    private static final int SMS_PERMISSION_REQUEST_CODE = 1002;
    private EditText phoneNumberEditText;
    private EditText messageEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        phoneNumberEditText = findViewById(R.id.phone_number_edit_text);
        messageEditText = findViewById(R.id.message_edit_text);

        Button callButton = findViewById(R.id.call_button);
        Button smsButton = findViewById(R.id.sms_button);

        callButton.setOnClickListener(this);
        smsButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.call_button) {
            call();
        } else if (view.getId() == R.id.sms_button){
            sendSMS();
        }
    }

    private void sendSMS() {
        String sendSMSPermission = Manifest.permission.SEND_SMS;
        if(ContextCompat.checkSelfPermission(this, sendSMSPermission) == PackageManager.PERMISSION_GRANTED){
            actionSendSMS();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{sendSMSPermission}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void actionSendSMS() {
        SmsManager.getDefault().sendTextMessage(getPhoneNumber(), null, getMessage(), null, null);
    }

    private String getMessage() {
        return messageEditText.getText().toString();
    }

    private String getPhoneNumber() {
        return phoneNumberEditText.getText().toString();
    }

    private void call() {
        String phonePermission = Manifest.permission.CALL_PHONE;
        if (ContextCompat.checkSelfPermission(this, phonePermission) == PackageManager.PERMISSION_GRANTED) {
            actionCall();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{phonePermission}, CALL_PERMISSION_REQUEST_CODE);
        }
    }

    private void actionCall() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + getPhoneNumber()));
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CALL_PERMISSION_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                actionCall();
            } else {
                Toast.makeText(this, "No Call Permission", Toast.LENGTH_SHORT).show();
            }

        } else if (requestCode == SMS_PERMISSION_REQUEST_CODE){
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                actionSendSMS();
            } else {
                Toast.makeText(this, "No SMS Permission", Toast.LENGTH_SHORT).show();
            }
        }
    }


}

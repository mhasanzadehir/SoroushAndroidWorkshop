package ir.sharif.androidworkshop;

import android.app.Notification;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    public static final int NOTIFICATION_ID = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        TextView welcomeTextView = findViewById(R.id.welcome);
        Button button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeNotification();
            }
        });

        Intent intent = getIntent();
        final String email = intent.getExtras().getString("EMAIL");

        welcomeTextView.setText("خوش آمدی" + email);
        welcomeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog(email);
            }
        });

        for (int i = 0; i < 20; i++) {
            raiseNotification(email, i);
        }
    }

    private void removeNotification() {
        NotificationManagerCompat.from(this).cancel(NOTIFICATION_ID);
    }

    private void raiseNotification(String email, int id) {
        Notification notification = new NotificationCompat.Builder(this)
                .setContentTitle("اعلان")
                .setContentText(String.format("Welcome %s", email))
                .setSmallIcon(R.mipmap.ic_launcher)
                .build();

        NotificationManagerCompat.from(this).notify(NOTIFICATION_ID + id, notification);
    }

    private void showDialog(final String email) {
        new AlertDialog.Builder(this)
                .setTitle("پیغام")
                .setMessage("آیا مایلید اطلاعات خود را ویرایش کنید؟")
                .setPositiveButton("بله", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        showEditDialog(email);
                    }
                })
                .setNegativeButton("خیر", null)
                .show();
    }

    private void showEditDialog(String email) {
        View view = LayoutInflater.from(this).inflate(R.layout.my_dialog, null);

        EditText emailEditText = view.findViewById(R.id.email);
        emailEditText.setText(email);

        new AlertDialog.Builder(this)
                .setView(view)
                .show();
    }

}

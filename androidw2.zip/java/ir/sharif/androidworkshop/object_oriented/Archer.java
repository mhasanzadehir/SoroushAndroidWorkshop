package ir.sharif.androidworkshop.object_oriented;

public class Archer extends Soldier implements Live, Attackable {
    private int numberOfArrows;

    public Archer(String name, int energy, int numberOfArrows) {
        super(name, energy);
        this.numberOfArrows = numberOfArrows;
    }

    public int getNumberOfArrows() {
        return numberOfArrows;
    }

    public void setNumberOfArrows(int numberOfArrows) {
        this.numberOfArrows = numberOfArrows;
    }

    @Override
    public void attack() {

    }

    @Override
    public void breathe() {

    }

    @Override
    public void walk() {

    }
}

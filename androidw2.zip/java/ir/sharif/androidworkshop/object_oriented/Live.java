package ir.sharif.androidworkshop.object_oriented;

public interface Live {
    void breathe();
    void walk();
}

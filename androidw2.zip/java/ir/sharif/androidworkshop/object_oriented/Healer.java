package ir.sharif.androidworkshop.object_oriented;

public class Healer extends Soldier implements Live{
    private int healPower;

    public Healer(String name, int energy, int healPower) {
        super(name, energy);
        this.healPower = healPower;
    }

    public void myMethod(){
        System.out.println("jbbhhbhjhj");
    }

    public int getHealPower() {
        return healPower;
    }

    public void setHealPower(int healPower) {
        this.healPower = healPower;
    }

    @Override
    public void breathe() {

    }

    @Override
    public void walk() {

    }
}

package ir.sharif.androidworkshop.object_oriented;

public abstract class Soldier {
    private String name;
    private int energy;

    public Soldier(String name, int energy) {
        this.name = name;
        this.energy = energy;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEnergy() {
        return energy;
    }

    public void setEnergy(int energy) {
        this.energy = energy;
    }
}

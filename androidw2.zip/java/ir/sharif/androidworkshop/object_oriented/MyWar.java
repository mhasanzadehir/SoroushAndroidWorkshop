//package ir.sharif.androidworkshop.object_oriented;
//
//import java.util.ArrayList;
//
//public class MyWar {
//
//    public static void main(String[] args) {
//        Archer archer1 = new Archer("Mahdi", 100, 3);
//        Archer archer2 = new Archer("Mahdi", 100, 3);
//        Archer archer3 = new Archer("Mahdi", 100, 3);
//        Healer healer1 = new Healer("Mostafa", 100, 100);
//        Healer healer2 = new Healer("Mostafa", 100, 100);
//        Healer healer3 = new Healer("Mostafa", 100, 100);
//
//        ArrayList<Healer> healers = new ArrayList<>();
//        healers.add(healer1);
//        healers.add(healer2);
//        healers.add(healer3);
//
//        ArrayList<Archer> archers = new ArrayList<>();
//        archers.add(archer1);
//        archers.add(archer2);
//        archers.add(archer3);
//
//        for (Healer healer : healers) {
//            healer.attack();
//        }
//
//        for (Archer archer : archers) {
//            archer.attack();
//        }
//
//        ArrayList<Soldier> list = new ArrayList<>();
//        list.add(healer1);
//        list.add(healer2);
//        list.add(healer3);
//        list.add(archer1);
//        list.add(archer2);
//        list.add(archer3);
//
//        for (Soldier soldier : list) {
//            soldier.attack();
//        }
//
//        Soldier mySoldier = new Archer("sss", 10, 20);
//
//
//    }
//}

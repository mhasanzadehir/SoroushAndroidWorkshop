package ir.sharif.androidworkshop.object_oriented;

public interface Attackable {
    void attack();
}

package ir.sharif.androidworkshop;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText emailEditText = findViewById(R.id.email_edit_text);
        final EditText passwordEditText = findViewById(R.id.password_edit_text);

        Button loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickOnLogin(emailEditText.getText().toString(), passwordEditText.getText().toString());
            }
        });
    }

    private void clickOnLogin(String email, String password) {
        Pattern pattern = Pattern.compile("[\\w-]+@([\\w-]+\\.)+[\\w-]+");
        Matcher matcher = pattern.matcher(email);
        if (matcher.matches()){
            if (email.equals("mahdi@gmail.com") && password.equals("123")){
                goToAnotherActivity(email);
            } else {
                Toast.makeText(this, "Login failed", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Email is not valid, try again", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToAnotherActivity(String email) {
        Intent intent = new Intent(this, Main3Activity.class);
        intent.putExtra("EMAIL", email);
        startActivity(intent);
//        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("Workshop", "On Start..." );
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("Workshop", "On Resume..." );
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("Workshop", "On Pause..." );
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("Workshop", "On Stop..." );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("Workshop", "On Destroy..." );
    }
}
